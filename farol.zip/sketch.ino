//Ana e Mguel Lipinski
int ledg = 8;
int ledy = 9;
int ledr = 10;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  pinMode(ledg, OUTPUT);
  pinMode(ledy, OUTPUT);
  pinMode(ledr, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(ledg, HIGH);
  digitalWrite(ledy, LOW);
  digitalWrite(ledr, LOW);
  Serial.println("Verde");
    delay(6000);
  digitalWrite(ledg, LOW);
  digitalWrite(ledy, HIGH);
  digitalWrite(ledr, LOW);
  Serial.println("Amarelo");
  delay(2000);
  digitalWrite(ledg, LOW);
  digitalWrite(ledy, LOW);
  digitalWrite(ledr, HIGH);
  Serial.println("Vermelho");
  delay(6000);
}